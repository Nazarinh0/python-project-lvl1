#!/usr/bin/python3.10
from brain_games.brain_even import even


def main():
    print(f'Welcome to the Brain Games!')




if __name__ == '__main__':
    main()
