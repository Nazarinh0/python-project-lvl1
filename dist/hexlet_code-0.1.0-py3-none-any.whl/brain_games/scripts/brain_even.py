#!/usr/bin/python3.10
print('Answer "yes" if the number is even, otherwise answer "no"')
