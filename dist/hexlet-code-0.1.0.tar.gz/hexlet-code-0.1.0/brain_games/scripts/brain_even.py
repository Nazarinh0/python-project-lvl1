#!/usr/bin/python3.10
import prompt
print('Answer "yes" if the number is even, otherwise answer "no"')
