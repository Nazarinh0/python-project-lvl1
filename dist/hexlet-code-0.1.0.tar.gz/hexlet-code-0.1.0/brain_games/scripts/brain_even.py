#!/usr/bin/python3.10
from brain_games.brain_even.play import play_even


def main():
    print(f'Welcome to the Brain Games!')
    play_even()


if __name__ == '__main__':
    main()
